<?php
    $link=@mysqli_connect(
        'localhost',
        'admin_root',
        'fuckuharry7414',
        'admin_dumplings'
    );
?>